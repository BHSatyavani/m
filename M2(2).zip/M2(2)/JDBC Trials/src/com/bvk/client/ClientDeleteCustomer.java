package com.bvk.client;

import java.util.Scanner;

import com.bvk.dao.CustomerDAO;
import com.bvk.dao.CustomerDAOImpl;
import com.bvk.entity.CustomerTO;

public class ClientDeleteCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scInput = new Scanner(System.in);
		
		int custId;
				
		CustomerTO customerTO = new CustomerTO();
		CustomerDAO customer = new CustomerDAOImpl();
		
		System.out.print("Enter custid: ");
		custId = scInput.nextInt();
				 scInput.nextLine();
				 
		customerTO.setCustId(custId);
		
		int status = customer.deleteCustomer(customerTO);
		
		if(status == 1){
			System.out.println("Record deleted..");
		}else{
			System.out.println("Unable to delete record..");
		}
	}
}