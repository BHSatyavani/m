package com.bvk.client;

public class Client1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int empid = 4;
		String name = new String("xyz");
		float salary = 50000;
		
		Dao dao = new Dao();
		
		int status = dao.insertUsingStatement(empid, name, salary);
		
		if(status > 0){
			System.out.println("Record inserted successfully...");
		}else{
			System.out.println("Record couldn't be inserted...");
		}
	}
}