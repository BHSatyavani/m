package com.bvk.client;

public class Client7 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dao dao = new Dao();
		dao.showRecords();
	}
}