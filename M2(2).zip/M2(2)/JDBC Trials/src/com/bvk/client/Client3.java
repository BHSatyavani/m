package com.bvk.client;

public class Client3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int empid = 12;
		String name = new String("def");
		float salary = 200000;
		
		Dao dao = new Dao();
		
		int status = dao.insertUsingCallableStatement(empid, name, salary);
		
		if(status > 0){
			System.out.println("Record inserted successfully...");
		}else{
			System.out.println("Record couldn't be inserted...");
		}
	}
}