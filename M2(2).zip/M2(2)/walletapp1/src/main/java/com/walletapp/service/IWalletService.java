package com.walletapp.service;

import com.walletapp.bean.CustomerDetails;
import com.walletapp.exception.WalletException;

public interface IWalletService {
	boolean validateEmployee(CustomerDetails cd) throws WalletException;
	Long addCustomer(CustomerDetails cd) throws WalletException;
	boolean validatePin(String string)throws WalletException;
	CustomerDetails getBalance(Long accnum,String pin) throws WalletException;
	CustomerDetails setDeposit(Long accnum, String pin, String amt) throws WalletException;
	CustomerDetails getWithdraw(Long accnum, String pin, String amt)throws WalletException;
	CustomerDetails getFundTransfer(Long accnum, Long oaccnum, String pin, String amt)throws WalletException;
	boolean getPrintTransactions(Long accnum, String pin)throws WalletException; 
}
