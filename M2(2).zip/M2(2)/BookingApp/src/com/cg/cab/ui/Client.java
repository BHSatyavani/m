package com.cg.cab.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.cg.cab.bean.CabRequest;
import com.cg.cab.exception.BookingException;
import com.cg.cab.service.BookingService;
import com.cg.cab.service.BookingServiceImpl;

public class Client {
	Scanner scan=new Scanner(System.in);
	BookingService bookingService=new BookingServiceImpl();
	public static void main(String[] args) {
		Client c=new Client();
		//c.scan.useDelimiter("\n");
		String option=null;
		while(true) {
		System.out.println("=========Booking Application========");
		System.out.println("1. Raise Cab Request");
		System.out.println("2. View Cab Request Status");
		System.out.println("3. Exit");
		System.out.println("Enter your choice");
		option=c.scan.nextLine();
		switch(option) {
		case "1":
			c.addRequest();
			break;
		case "2":
			c.viewRequest();
			break;
		case "3":
			System.exit(0);
			break;
		default:
		System.out.println("Enter valid option within 1 and 3");
			break;
		}
		}
	}
	public void addRequest() {
		CabRequest request=new CabRequest();
		/*System.out.println("Enter Request Id");       //for new code comment these two lines of request id
		request.setRequestId(Integer.parseInt(scan.nextLine()));*/
		System.out.println("Customer Name");
		request.setCustomerName(scan.nextLine());
		System.out.println("Enter Phone Number");
		request.setPhoneNumber(scan.nextLine());
		System.out.println("Enter Pickup Address");
		request.setPickupAddress(scan.nextLine());
		System.out.println("Enter Pincode");
		request.setPincode(scan.nextLine());
		try {
			boolean result=bookingService.validateRequest(request);
			if(result) {
				request.setDateOfRequest(LocalDate.now());
				request.setStatus("Not Accepted");
				int ret=bookingService.addRequest(request);
				System.out.println("Request has been successfully registered. Your request ID is : "+ret);
			}
		}
		catch(BookingException ex) {
			System.out.println();
			System.err.println("An error occured : " +ex.getMessage());
			System.out.println();
		}
	}
	public void viewRequest() {
		System.out.println("Enter Request Id");
		String id=scan.nextLine();
		try {
		int reqId=Integer.parseInt(id);
			CabRequest request = bookingService.getRequest(reqId);
			System.out.println("Name of the customer : "+request.getCustomerName());
			System.out.println("Request Status : "+request.getStatus());
			System.out.println("Cab Number : "+request.getCabNumber());
			System.out.println("Pickup Address : "+request.getPickupAddress());
		} catch (BookingException e) {
			System.out.println();
			System.err.println("An error occured : " +e.getMessage());
			System.out.println();
		}
		catch(Exception e) {
			System.out.println();
			System.err.println("An error occured : " +e.getMessage());
			System.out.println();
		}
	}
	
}
