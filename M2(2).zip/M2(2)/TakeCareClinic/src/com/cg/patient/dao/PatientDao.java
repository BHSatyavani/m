package com.cg.patient.dao;

import com.cg.patient.bean.Patient;
import com.cg.patient.exception.PatientException;

public interface PatientDao {
	public int addPatientInformation(Patient request) throws PatientException;
	Patient searchPatientById(int id) throws PatientException;
}
