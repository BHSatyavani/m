package com.cg.patient.ui;

import java.time.LocalDate;
import java.util.Collection;
import java.util.Scanner;
import com.cg.patient.bean.Patient;
import com.cg.patient.exception.PatientException;
import com.cg.patient.service.PatientService;
import com.cg.patient.service.PatientServiceImpl;


public class PatientMain {
	PatientService patientService=new PatientServiceImpl();
	Scanner scan=new Scanner(System.in);
	public static void main(String[] args) {
		PatientMain p=new PatientMain();
		//p.scan.useDelimiter("\n");
		String option=null;
		while(true) {
		System.out.println("=========Patient Information========");
		System.out.println("1. Add Patient Information");
		System.out.println("2. Search patient by Id");
		System.out.println("3. Exit");
		System.out.println("Enter your choice");
		option=p.scan.nextLine();
		switch(option) {
		case "1":
			p.addPatientInformation();
			break;
		case "2":
			p.searchPatientById();
			break;
		case "3":
			System.exit(0);
			break;
		default:
		System.out.println("Enter valid option within 1 and 3");
			break;
		}
		}
	}
	
	public void addPatientInformation(){
		Patient details=new Patient();
		System.out.println("Enter the name of the Patient");
		details.setName(scan.nextLine());
		System.out.println("Enter Patient Age");
		details.setAge(scan.nextLine());;
		System.out.println("Enter Patient Phone Number");
		details.setPhone(scan.nextLine());
		System.out.println("Enter Description");
		details.setDescription(scan.nextLine());
		System.out.println();
		try {
			boolean result=patientService.validateDetails(details);
			if(result) {
				int ret=patientService.addPatientInformation(details);
				System.out.println("Patient information stored successfully. Your patient ID is "+ret);
				System.out.println();
			}
		}
		catch(PatientException ex) {
			System.out.println();
			System.err.println("An error occured : " +ex.getMessage());
			System.out.println();
		}
	}
	
	public void searchPatientById() {
		System.out.println("Enter Patient Id");
		String id=scan.nextLine();
		try {
		int reqId=Integer.parseInt(id);
			Patient details = patientService.searchPatientById(reqId);
			System.out.println();
			System.out.println("Name of the Patient : "+details.getName());
			System.out.println("Age : "+details.getAge());
			System.out.println("Phone Number : "+details.getPhone());
			System.out.println("Description : "+details.getDescription());
			System.out.println("Consultation Date : "+LocalDate.now());
			System.out.println();
		}
		catch(PatientException e){
			System.out.println();
			System.err.println("An Error Occured "+e.getMessage());
			System.out.println();
		}
		/*catch(Exception e) {
			System.out.println();
			System.err.println("An Error Occured "+e.getMessage());
			System.out.println();
		}*/
}
	}
	


