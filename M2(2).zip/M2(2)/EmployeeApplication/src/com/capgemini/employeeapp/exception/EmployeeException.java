package com.capgemini.employeeapp.exception;

public class EmployeeException extends Exception  {
	private static final long serialVersionUID = 726264577455921591L;

	public EmployeeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
