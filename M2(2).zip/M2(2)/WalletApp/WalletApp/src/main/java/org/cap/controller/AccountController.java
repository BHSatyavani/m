package org.cap.controller;

import java.util.List;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AccountController {

	@PostMapping("/validateLogin")
	public String validateLogin(ModelMap map, 
			@RequestParam("userName")String userName,
			@RequestParam("userPwd")String userPwd) {
		
		
		if(userName.equals("tom") && 
				userPwd.equals("tom123")) {
			
			return "main";
		}
		
		return "redirect:/";
	}
	
	
	
	
	
	
	
	@RequestMapping("/createAccount")
	public String showCreateAccountPage() {
		return "createAccount";
	}

	@RequestMapping("/showBalance")
	public String showBalancePage() {
		return "showBalance";
	}
	
	@RequestMapping("/deposit")
	public String showDepositPage() {
		return "/deposit";
	
	}
	
	@RequestMapping("/withdraw")
	public String showWithdrawPage() {
		return "/withdraw";
	
	}
	
	@RequestMapping("/fundTransfer")
	public String showfundTransferPage() {
		return "/fundTransfer";
	
	}
	@RequestMapping("/logout")
	public String showlogoutPage() {
		return "redirect:/";
	
	}
	
}
