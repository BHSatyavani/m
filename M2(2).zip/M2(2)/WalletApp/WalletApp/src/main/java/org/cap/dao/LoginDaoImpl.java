package org.cap.dao;

import javax.persistence.EntityManager;
import javax.persistence.Query;

//public class LoginDaoImpl implements ILoginDao {

//	@Override
	//public boolean validateLogin(int customerId, String custPwd) {
	//	Query query=entityManager.createQuery("From Customer where cutomer Id=? and custPwd=?")
	//query.setParameter(1, customerId);	// TODO Auto-generated method stub
	//	return false;
//	}

	

//}
