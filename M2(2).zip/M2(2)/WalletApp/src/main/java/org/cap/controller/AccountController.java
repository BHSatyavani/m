package org.cap.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.service.IAccountService;
import org.cap.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AccountController {
	@Autowired
	private ILoginService loginService;
	
	@Autowired
	private IAccountService acccountService;
	@PostMapping("/validateLogin")
	public String validateLogin(ModelMap map, 
			@RequestParam("customerId") String customerId,
			@RequestParam("customerPwd") String customerPwd,
			HttpSession session) {
		System.out.println(customerId+","+customerPwd);
		Integer custId=Integer.parseInt(customerId);
		
	
		if(loginService.validateLogin(custId, customerPwd)) {
			//Store CustId into the session object
			System.out.println(custId);
			session.setAttribute("custId", custId);
			
			String custName=loginService.getCustomerName(custId);
			map.put("custName", custName);
			
			return "main";
			
			
		}
		
		return "redirect:/";
	}
	
	
	
	
	
	
	
	
	
	@RequestMapping("/createAccount")
	public String showCreateAccountPage() {
		return "createAccount";
	}
	@PostMapping("/saveAccount")
	public String saveAccountDetails(HttpSession session,
			@ModelAttribute("account") Account account) {
		account.setOpeningDate(new Date());
		Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
		
		//Customer customer= loginService.findCustomer(customerId);
		Customer customer=new Customer();
		customer.setCustomerId(customerId);
		account.setCustomer(customer);
		
		account.setStatus("active");
		
		//System.out.println(account);
		
		acccountService.createAccount(account);
		
		return "redirect:createAccount";
	}

	@RequestMapping("/showBalance")
	public String showBalancePage() {
		return "showBalance";
	}
	
	@RequestMapping("/deposit")
	public String showDepositPage() {
		return "/deposit";
	
	}
	
	@RequestMapping("/withdraw")
	public String showWithdrawPage() {
		return "/withdraw";
	
	}
	
	@RequestMapping("/fundTransfer")
	public String showfundTransferPage() {
		return "/fundTransfer";
	
	}
	@RequestMapping("/logout")
	public String showlogoutPage() {
		return "redirect:/";
	
	}
	
}
