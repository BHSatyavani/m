package com.cg.productmgmt.dao;
/**
 * Class Name   :   ProductdDAO
 *Method        :  getProductDetails,updateProduct
 * Purpose       :  to get and update the map data
 * 
 * 
 * Author        :   AKASH Patel
 * Date of Creation : 4th july, 2018
 * 
 *
 */
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.cg.productmgmt.exception.ProductException;

public class ProductDAO implements IProductDAO {
static Map<String,String> productDetails;
static Map<String,Integer> salesDetails;

static {
	productDetails=new HashMap<>();
	productDetails.put("lux","soap");
	productDetails.put("colgate","paste");
	productDetails.put("pears","soap");
	productDetails.put("sony","electronics");
	productDetails.put("samsung","electronics");
	productDetails.put("facepack","cosmatic");
	productDetails.put("facecream","cosmatic");
	
	salesDetails=new HashMap<>();
	salesDetails.put("lux",100);
	salesDetails.put("colgate",50);
	salesDetails.put("pears",70);
	salesDetails.put("sony",10000);
	salesDetails.put("samsung",23000);
	salesDetails.put("facepack",100);
	salesDetails.put("facecream",160);
	
	
	
}
/**
 * Method Name   :   getProductDetails
 * Parameters    :   null
 * Return type   :   Map
 * Purpose       :  to get the map data
 * 
 * 
 * Author        :   AKASH Patel
 * Date of Creation : 4th july, 2018
 * 
 *
 */

 @Override
 public Map<String,Integer>getProductDetails() throws ProductException{
	 
try {
	return salesDetails;
}	 
catch(Exception ex)
{
	throw new ProductException(ex.getMessage());
}
	 
	 
 }
 /**
  * Method Name   :  updateProduct
  * Parameters    :   category,hike
  * Return type   :   integer
  * Purpose       :  to update the map data
  * 
  * 
  * Author        :   AKASH Patel
  * Date of Creation : 4th july, 2018
  * 
  *
  */
 @Override
public int updateProducts(String category,int hike) throws ProductException{
	 if(hike >0) {
	 Set<String> product=new HashSet<String>();
	 
	 Set<String> keys=productDetails.keySet();
	 String value=null;
	 int newPrice=0;
	 int updated=0;
	 boolean isUpdated=false;
	 for(String key:keys)
	 {
		 value=productDetails.get(key);
		 if(value.equals(category)) {
			 product.add(key);
			 
		 }
		 
	 }
	 Set <String> keySales=salesDetails.keySet();
	 for(String sale:keySales) {
		 if(product.contains(sale)) {
			 newPrice=salesDetails.get(sale);
			 newPrice+=hike;
			 salesDetails.put(sale, newPrice);
			 updated=1;
		 }
	 }
	 return updated;
	 
 }
 else
	 throw new ProductException("hike rate should be greater than zero");
	 }
}