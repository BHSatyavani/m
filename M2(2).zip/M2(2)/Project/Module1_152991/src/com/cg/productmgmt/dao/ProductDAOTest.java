package com.cg.productmgmt.dao;

import static org.junit.Assert.*;

import java.util.Map;

import org.junit.Test;

import com.cg.productmgmt.exception.ProductException;

public class ProductDAOTest {
	IProductDAO dao=new ProductDAO();
	@Test
	public void testGetProductDetails() {
		try {
			Map<String,Integer> p=dao.getProductDetails();
			assertEquals(7,dao.getProductDetails().size());
		}
		catch(ProductException e) {
			e.printStackTrace();}
		
	}

	@Test
	public void testUpdateProducts() throws ProductException {
		int i=dao.updateProducts("soap",1);
		assertEquals(1,i);
		
	}

}
