package com.cg.productmgmt.ui;

import java.util.Collection;
import java.util.Map;
import java.util.Scanner;


import com.cg.productmgmt.bean.ProductDetails;
import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.IProductService;
import com.cg.productmgmt.service.ProductService;


public class Client {
	IProductService pservice=new ProductService();
	ProductDetails pd=new ProductDetails();
	Scanner scan=new Scanner(System.in);
	public static void main(String[] args) throws ProductException {
		
		
		String option=null;
		Client c=new Client();
		while(true) {
			System.out.println("==================Product Management Sysytem=================");
	System.out.println("1.Update Product List");	
	System.out.println("2. Display Product List ");
	System.out.println("3. Exit");
	System.out.println("Enter Your Choice");
	
	
	option=c.scan.nextLine();
	 switch(option) {
	 case "1":
		 c.updateProduct();
		 break;
	 case "2":
		 c.getProductDetails();
		
		 break;
	 case "3":
		 System.exit(0);
		 default:
			 System.err.println("Invaild , Chosse from 1 to 3");
			 break;
	
		
		}

		}
	}
	
//	void updateProduct() throws ProductException {
//		System.out.println("Enter the Product Category");
//		String category=scan.nextLine();
//		System.out.println("Enter the Hike Rate");
//		String hike=scan.nextLine();
//		int hike1=Integer.parseInt(hike);
//		int i=pservice.updateProducts(category,hike1);
//		if(i==0)
//		{
//			System.out.println("Updated List");
//			Map<String,Integer> products=pservice.getProductDetails();
//			System.out.println(products);
//		}
//		else
//			System.out.println("there is an error");
//	
//		}
	void updateProduct() {
		try {
			
			System.out.println("Enter the product Catogry");
			String category=scan.nextLine();
			System.out.println("Enter the hike");
			int hike=Integer.parseInt(scan.nextLine());
			int ret=pservice.updateProducts(category,hike);
			if(ret==1) {
				System.out.println("successfully hiked for"+category+"by"+hike);
			}
			
		}
		catch(ProductException e) {
			System.out.println("error occured"+e.getMessage());
		}
	}
	
		
		void getProductDetails() {
			try {
				Map<String,Integer> products=pservice.getProductDetails();
				System.out.println(products);
			
			} catch (ProductException e) {
				System.err.println("An Error Occured "+e.getMessage());
			}
		}
		}
		
		
		
		
		
		
	



