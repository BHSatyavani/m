package com.wallet.db;

import java.util.HashMap;

import com.wallet.bean.Customer;

public class CustomerDB {
	private static HashMap<Double,Customer> 
    customerMap=new HashMap<Double,Customer>();
	
	private static HashMap<Double,Integer> 
    detailsMap=new HashMap<Double,Integer>();
	
	private static HashMap<Integer,Double> 
    addCustomerMap=new HashMap<Integer,Double>();
	
	/*private static HashMap<Double,String> 
    transactionMap=new HashMap<Double,String>();*/
	
	private static HashMap<String,Double> 
    transactionMap=new HashMap<String,Double>();
	
	static
	{
	 detailsMap.put(10453789844d,12345);
	 detailsMap.put(10453789854d,12355);
	 detailsMap.put(10453789864d,12366);
	 detailsMap.put(10453789874d,12377);
	 detailsMap.put(10453789884d,12388);
	 detailsMap.put(10453789894d,12399);
	 
	}
	   
static{
customerMap.put(10453789844d, new Customer(10453789844d,"Prakash","123412341234","9999999999","prakash@gmail.com",99000)); 
customerMap.put(10453789854d, new Customer(10453789854d,"Anmol","123412341212","8888888888","anmol@outlok.com",87000)); 
customerMap.put(10453789864d, new Customer(10453789864d,"Shucheta","123412341240","7777777777","shucheta@yahoo.com",97000)); 
customerMap.put(10453789874d, new Customer(10453789874d,"Aakash","123412341223","6666666666","aakash@gmail.com",159000)); 
customerMap.put(10453789884d, new Customer(10453789884d,"Anubhav","123412341267","9454646464","anubhav@ymail.com",94582));
customerMap.put(10453789894d, new Customer(10453789894d,"Praguu","123412341299","6969669669","praguu@gmail.com",20000)); 


}
	public static HashMap<Double,Customer> getCustomerMap() {
		return customerMap;
	}
	public static HashMap<Double,Integer> getDetailsMap() {
		return detailsMap;
	}
	public static HashMap<Integer,Double> getaddCustomerMap() {
		return addCustomerMap;
	}
	
	public static HashMap<String,Double> gettransactionMap() {
		return transactionMap;
	}
	
	
}
