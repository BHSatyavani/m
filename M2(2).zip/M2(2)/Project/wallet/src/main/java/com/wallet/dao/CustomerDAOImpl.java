package com.wallet.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Scanner;

import com.wallet.bean.Customer;
import com.wallet.db.CustomerDB;
import com.wallet.exception.CustomerException;

public class CustomerDAOImpl implements CustomerDAO{
	static HashMap<Double, Customer> customerMap=CustomerDB.getCustomerMap();
	static HashMap<Double,Integer> detailsMap=CustomerDB.getDetailsMap();
	static HashMap<Integer,Double> addCustomerMap=CustomerDB.getaddCustomerMap();
	static HashMap<String,Double> transactionMap=CustomerDB.gettransactionMap();

	
	public Customer addCustomer(double accNo,int pass) throws CustomerException {
		
		// TODO Auto-generated method stub
		try {
			
			boolean result=detailsMap.containsKey(accNo);
			if(result)
			{
			int r=detailsMap.get(accNo);
			if(r==pass)
			{
				Customer c=customerMap.get(accNo);
				System.out.println("Enter new password");
				int pas=Integer.parseInt(new Scanner(System.in).nextLine());
				addCustomerMap.put(pas, accNo);
				return c;
			}
			else
			{
				throw new CustomerException("Password Is inncorrect");
			}
			}
			else
			{
				throw new CustomerException("Enter correct account no");
			}
			
	}
		catch(Exception e)
		{
			throw new CustomerException(e.getMessage());
		}
	

}

	public double showBalance(int pass) throws CustomerException {
	
		try
		{   if(addCustomerMap.get(pass)==null)
		{
			throw new CustomerException("Enter Password is not valid");
		}
			double c=addCustomerMap.get(pass);
		
		
		 Customer c1=customerMap.get(c);
		 return c1.getBalance();
		}
		catch(CustomerException e)
		{
			 throw new CustomerException(e.getMessage());
		}
		
	}

	public double deposit(int pass) throws CustomerException {
	
		try
		{   if(addCustomerMap.get(pass)==null)
		{
			throw new CustomerException("Enter Password is not valid");
		}
		double c=addCustomerMap.get(pass);
		System.out.println("Enter the money u want to deposit");
		double d=Double.parseDouble(new Scanner(System.in).nextLine());
		 Customer c1=customerMap.get(c);
         double bal=c1.getBalance();
         c1.setBalance(bal+d);
         transactionMap.put("credited :"+d,c);
         return c;
	}
		catch(CustomerException e)
		{
			 throw new CustomerException(e.getMessage());
		}
		}

	public double withdraw(int pass) throws CustomerException {
		try
		{   if(addCustomerMap.get(pass)==null)
		{
			throw new CustomerException("Enter Password is not valid");
		}
		double c=addCustomerMap.get(pass);
		System.out.println("Enter the money u want to withdraw");
		
		double d=Double.parseDouble(new Scanner(System.in).nextLine());
		
		 Customer c1=customerMap.get(c);
		 
         double bal=c1.getBalance();
         if((bal-d)<=1000)
         {
        	 throw new CustomerException("Your account does not have sufficien balance to withdraw");
         }
         c1.setBalance(bal-d);
         transactionMap.put("debited :"+d,c);
         return c;
	}
		catch(CustomerException e)
		{
			 throw new CustomerException(e.getMessage());
		}
	}

	public double fundTransfer(int pass) throws CustomerException {

		try
		{   if(addCustomerMap.get(pass)==null)
		{
			throw new CustomerException("Enter Password is not valid");
		}
		double c=addCustomerMap.get(pass);
		System.out.println("Enter the account no u want to transfer money");
		double ac=Double.parseDouble(new Scanner(System.in).nextLine());
		if(customerMap.get(ac)==null)
		{
			throw new CustomerException("Enterd Payee is not Available");
		}
		System.out.println("Enter the amount u want to transfer");
		double d=Double.parseDouble(new Scanner(System.in).nextLine());
		
		 Customer c1=customerMap.get(ac);
		 Customer c2=customerMap.get(c);
		 
		 double bal1=c1.getBalance();
         double bal=c2.getBalance();
         
         if((bal-d)<=1000)
         {
        	 throw new CustomerException("Your account does not have sufficien balance to Transfer");
         }
         c1.setBalance(bal1+d);
         c2.setBalance(bal-d);
         transactionMap.put("fund :"+d +" transferd to account"+ac,c);
         return ac;
	}
		catch(CustomerException e)
		{
			 throw new CustomerException(e.getMessage());
		}
	}

	public int transaction(int pass) throws CustomerException {
		
		try
		{   if(addCustomerMap.get(pass)==null)
		{
			throw new CustomerException("Enter Password is not valid");
		}
		double c=addCustomerMap.get(pass);
		for(Map.Entry<String,Double> s:transactionMap.entrySet())
		{
			if(s.getValue()==c)
			{
				System.out.println(s.getKey());
			}
		}
		
		}
		catch(CustomerException e)
		{
			 throw new CustomerException(e.getMessage());
		}
		
		return 1;
	}
}
