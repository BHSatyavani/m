package com.wallet.service;

import java.util.Map;

import com.wallet.bean.Customer;
import com.wallet.exception.CustomerException;

public interface WalletService {

	Customer addCustomer(double accNo,int pass) throws CustomerException;
	double showBalance(int pass) throws CustomerException;
	double deposit(int pass)throws CustomerException;
	double withdraw(int pass)throws CustomerException;
	double fundTransfer(int pass)throws CustomerException;
	 int transaction(int pass)throws CustomerException;

	





}
