package com.wallet.bean;

public class Customer {
	public int getPass() {
		return pass;
	}
	public void setPass(int pass) {
		this.pass = pass;
	}
	private double accNo;
	private String name;
	private String aadharNo;
	private String phoneNo;
	private String email;
	private double balance;
	private int pass;
	public Customer(double accNo, String name, String aadharNo, String phoneNo, String email, double balance) {
		super();
		this.accNo = accNo;
		this.name = name;
		this.aadharNo = aadharNo;
		this.phoneNo = phoneNo;
		this.email = email;
		this.balance = balance;
	}
	public Customer() {
		// TODO Auto-generated constructor stub
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public double getAccNo() {
		return accNo;
	}
	public void setAccNo(double accNo) {
		this.accNo = accNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	

}
