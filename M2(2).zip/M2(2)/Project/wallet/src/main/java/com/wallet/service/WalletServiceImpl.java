package com.wallet.service;

import com.wallet.bean.Customer;
import com.wallet.dao.CustomerDAO;
import com.wallet.dao.CustomerDAOImpl;
import com.wallet.exception.CustomerException;

public class WalletServiceImpl implements WalletService{
CustomerDAO cdao=new CustomerDAOImpl();

	public Customer addCustomer(double accNo,int pass) throws CustomerException {
		// TODO Auto-generated method stub
		return cdao.addCustomer(accNo,pass);
	}
	public double showBalance(int pass) throws CustomerException {
		// TODO Auto-generated method stub
		return cdao.showBalance(pass);
	}
	public double deposit(int pass) throws CustomerException {
		// TODO Auto-generated method stub
		return cdao.deposit(pass);
	}
	public double withdraw(int pass) throws CustomerException {
		// TODO Auto-generated method stub
		return cdao.withdraw(pass);
	}
	public double fundTransfer(int pass) throws CustomerException {
		// TODO Auto-generated method stub
		return cdao.fundTransfer(pass);
	}
	public int transaction(int pass) throws CustomerException {
		// TODO Auto-generated method stub
		return cdao.transaction(pass);
	}
	

}
