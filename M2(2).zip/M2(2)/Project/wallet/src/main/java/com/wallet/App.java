package com.wallet;

import java.util.Scanner;

import com.wallet.bean.Customer;
import com.wallet.exception.CustomerException;
import com.wallet.service.WalletService;
import com.wallet.service.WalletServiceImpl;


public class App 
{  Scanner sc=new Scanner(System.in);

WalletService ws=new WalletServiceImpl();
    public static void main( String[] args )
    {  App a=new App();
      while(true)
      {
    	  System.out.println("===============================Banking Wallet===============================");
        System.out.println("1. Add Account");
        System.out.println("2. View Balance");
        System.out.println("3. withdraw Money");
        System.out.println("4. Deposit Money");
        System.out.println("5. Fund Transfer");
        System.out.println("6.Transaction Summery");
        System.out.println("7. Exit");
        
        String choice=null;
        System.out.println("Enter your choice");
        choice=a.sc.nextLine();
        switch(choice)
        {
        case "1":
        	a.createAccount();
        	break;
        case "2":
        	a.showBalance();
        	break;
        case "3":
        	a.withdraw();
        	break;
        case "4":
        	
        	a.deposit();
        	break;
        case "5":
        	a.fundTransfer();
        	break;
        case "6":
        	a.transaction();
        	break;
        case "7":
        	System.exit(0);
        default :
        	System.out.println("Enter a choice between 1 to 6");
        	break;
        	
        }
        
      }
        
    }
    
    void createAccount()
    {Customer c=new Customer();
    	System.out.println("Enter Accountno");
    	double accNo=Double.parseDouble(sc.nextLine());
    	System.out.println("Enter Security Code");
    	int pass=Integer.parseInt(sc.nextLine());
 
 	   try
 	   {
 		  
 		
 			 
 			  Customer ret=ws.addCustomer(accNo,pass);
 			  System.out.println(" successfully registereed .");
 			 System.out.println("Name of The Customer :"+ret.getName());
 			System.out.println("Aadhatr No :"+ret.getAadharNo());
 			System.out.println("Account Number :"+ret.getAccNo());
 			System.out.println("Balance :"+ret.getBalance());
 			System.out.println("Email Address :"+ret.getEmail());
 			System.out.println("Phone Number :"+ret.getPhoneNo());
 			
 		  
 	   }
 	   catch(CustomerException ex)
 	   {
 		   System.out.println();
 		   System.err.println("An Error Occured :" +ex.getMessage());
 		   System.out.println();
 	   }   	
    	
    }
    
    void showBalance()
    {
    	System.out.println("Enter Wallet Password Number");
    	
    	try
    	{int pass=Integer.parseInt(sc.nextLine());
    		double ret=ws.showBalance(pass);
    		System.out.println("Available Balance is :"+ret);
    	}
    	catch(CustomerException ex)
  	   {
  		   System.out.println();
  		   System.err.println("An Error Occured :" +ex.getMessage());
  		   System.out.println();
  	   }
    	
    }
    
    
    void deposit()
    {
    	System.out.println("Enter Wallet Password");
    	try
    	{int pass=Integer.parseInt(sc.nextLine());
    		double ret=ws.deposit(pass);
    		System.out.println(" Balance is deposited in your account:"+ ret);
    	}
    	catch(CustomerException ex)
  	   {
  		   System.out.println();
  		   System.err.println("An Error Occured :" +ex.getMessage());
  		   System.out.println();
  	   }
    	
    }
    
    
    void withdraw()
    {
    	System.out.println("Enter Wallet Password");
    	try
    	{int pass=Integer.parseInt(sc.nextLine());
    		double ret=ws.withdraw(pass);
    		System.out.println(" Balance is withdrawn from your account:"+ ret);
    	}
    	catch(CustomerException ex)
  	   {
  		   System.out.println();
  		   System.err.println("An Error Occured :" +ex.getMessage());
  		   System.out.println();
  	   }
    	
    }
    
    void fundTransfer()
    {
    	System.out.println("Enter Wallet Password");
    	try
    	{int pass=Integer.parseInt(sc.nextLine());
    		double ret=ws.fundTransfer(pass);
    		System.out.println(" Balance is transfered from your account to account:"+ ret);
    	}
    	catch(CustomerException ex)
  	   {
  		   System.out.println();
  		   System.err.println("An Error Occured :" +ex.getMessage());
  		   System.out.println();
  	   }
    	
    }
    
    
    void transaction()
    {
    	System.out.println("Enter Wallet Password");
    	try
    	{int pass=Integer.parseInt(sc.nextLine());
    		int ret=ws.transaction(pass);
    		//System.out.println(" Balance is transfered from your account to account:"+ ret);
    	}
    	catch(CustomerException ex)
  	   {
  		   System.out.println();
  		   System.err.println("An Error Occured :" +ex.getMessage());
  		   System.out.println();
  	   }
    	
    }
    
    
}
